package com.example.demo;

import javax.websocket.server.PathParam;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//controlle
@RestController
public class helloworld {

	//GET
	//URI  /hello-world
	//method 
	//@RequestMapping(method = RequestMethod.GET,path="/hello-world")
	@GetMapping(path = "/hello-world")
	public String helloWorld() {
		return "hello world ";
	}
	
	//hello-world-bean
	
//	@GetMapping(path = "/hello-world-bean")
//	public k helloWorldBean() {
//		return new k('k');
//	}
	
//	@GetMapping( path= "/hello-world/path-var/{name}")
//	public HelloWorldBean helloWorldpath(@PathVariable String name) {
//		return new HelloWorldBean(String.format("hello world,%s",name));
//		
//	}
}  
