package com.example.demo;
import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
 
import org.springframework.web.bind.annotation.*;
 
@RestController
public class productcontroler {
 
    @Autowired
    private productservice service;
     
    // RESTful API methods for Retrieval operations
     
    // RESTful API method for Create operation
     
    // RESTful API method for Update operation
     
    // RESTful API method for Delete operation
    
    @GetMapping("/products")
    public List<product> list() {
        return service.listAll();
    }
    
    @PostMapping("/products")
    public void add(@RequestBody product product) {
        service.save(product);
    }
    
    @PutMapping("/products/{id}")
    public ResponseEntity<?> update(@RequestBody product product, @PathVariable Integer id) {
        try {
            product existProduct = service.get(id);
            service.save(product);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }      
    }
    
    @DeleteMapping("/products/{id}")
    public void delete(@PathVariable Integer id) {
        service.delete(id);
    }
}
