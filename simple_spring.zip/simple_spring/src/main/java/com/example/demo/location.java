package com.example.demo;

public class location {
	long id;
	String sate;
	String city;
	String  Country;
	public location(long id, String sate, String city, String country) {
		super();
		this.id = id;
		this.sate = sate;
		this.city = city;
		Country = country;
	}
	public long getId() {
		return id;
	}
	public String getSate() {
		return sate;
	}
	public String getCity() {
		return city;
	}
	public String getCountry() {
		return Country;
	}
	@Override
	public String toString() {
		return "location [id=" + id + ", sate=" + sate + ", city=" + city + ", Country=" + Country + "]";
	}
	

}
