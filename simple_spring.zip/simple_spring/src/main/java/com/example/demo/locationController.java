package com.example.demo;


import java.util.Arrays;
import java.util.List;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class locationController {
@GetMapping("/location")
public List<location> getAllLocation()
{
	return Arrays.asList(new location(1,"mp","hm","hg"));
}
}
